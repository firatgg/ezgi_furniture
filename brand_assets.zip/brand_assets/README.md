# EZGI CRAFT — Asset Paketi

## Renkler
| Renk  | HEX     | RGB           | CMYK          |
|-------|---------|---------------|---------------|
| Altın | #C5A26B | 197, 162, 107 | 24, 34, 65, 4 |
| Siyah | #111111 | 17, 17, 17    | 0, 0, 0, 93   |
| Beyaz | #FFFFFF | 255,255,255   | —             |

## Klasörler
- `horizontal/` — Ana logo varyasyonları (PNG 500/1000/2000/4000 + SVG)
  - `renkli` — siyah metin + altın vurgu (şeffaf)
  - `beyaz` — beyaz metin + altın vurgu (şeffaf, koyu zemin)
  - `negatif-acik` — beyaz metin, altın zemin
  - `negatif-koyu` — altın metin, siyah zemin
- `vertical/` — Dikey ve ikonlu dikey versiyonlar
- `icon/` — Tek başına E. ikonu
- `web/` — Favicon & PWA ikonları
- `social/` — Yuvarlak profil görselleri
- `print/` — 300 DPI baskı PNG
- `vector/` — SVG kaynaklar

## Kullanım
- Oranları bozmayın, uzatmayın.
- Minimum boşluk ≈ nokta yarıçapının 2×'i.
- Zemine göre doğru varyasyonu seçin.
- Logo üstüne başka eleman bindirmeyin.

Not: AI / EPS / CMYK PDF için SVG dosyalarını Illustrator veya Affinity'de açıp dışa aktarın.
